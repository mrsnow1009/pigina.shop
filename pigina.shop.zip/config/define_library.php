<?php 

	$_ARRAY_WATERMARK = array(
		'status'=>0,
		'path_img'=>_PHISICAL_PATH_ROOT.'resource/upload/watermark/watermark.png',
		'marginRight'=>15,
		'marginBottom'=>15,
		'quality'=>100,
		'opacity'=>100
	);
	define('_ARRAY_WATERMARK',serialize($_ARRAY_WATERMARK));

?>