<?php

	/* define array logo size */
	$_ARR_SIZE_LOGO_COMPANY = array(
	    0 => array(300,100),
	);
	define("_ARR_SIZE_LOGO_COMPANY",serialize($_ARR_SIZE_LOGO_COMPANY));

	/* define array logo_footer size */
	$_ARR_SIZE_LOGO_FOOTER_COMPANY = array(
	    0 => array(300,100),
	);
	define("_ARR_SIZE_LOGO_FOOTER_COMPANY",serialize($_ARR_SIZE_LOGO_FOOTER_COMPANY));

	/* define array favicon size */
	$_ARR_SIZE_FAVICON_COMPANY = array(
	    0 => array(128,128),
	);
	define("_ARR_SIZE_FAVICON_COMPANY",serialize($_ARR_SIZE_FAVICON_COMPANY));

?>