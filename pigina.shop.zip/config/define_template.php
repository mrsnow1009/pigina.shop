<?php
    /* MASK: order template send mail */
	define('_MASK_SENDEMAIL','order_email');

?>