<?php
define('TBLWEBMASTER','tblwebmaster');
define('TBLBANNER_GROUP','tblbanner_group');
define('TBLBANNER','tblbanner');
define('TBLCATEGORY','tblcategory');
define('TBLCONTENT','tblcontent');
define('TBLPRODUCT','tblproduct');
define('TBLPRODUCT_PRICE','tblproduct_price');
define('TBLSEO','tblseo');
define('TBLMEMBER','tblmember');
define('TBLLIBRARY','tbllibrary');
define('TBLUNIT','tblunit');
define('TBLORDER','tblorder');
define('TBLORDER_DETAIL','tblorder_detail');
define('TBLORDER_BUYER','tblorder_buyer');
define('TBLORDER_RECEIVER','tblorder_receiver');
define('TBLORDER_NOTE','tblorder_note');
define('TBLDELIVERYMETHOD','tbldeliverymethod');
define('TBLPAYMENTMETHOD','tblpaymentmethod');
define('TBLTEMPLATE','tbltemplate');
define('TBLCOMPANY','tblcompany');
define('TBLBRANCH','tblbranch');
define('TBLBRAND','tblbrand');
define('TBLCONFIG','tblconfig');
define('TBLCOLOR','tblcolor');
define('TBLSIZE','tblsize');
define('TBLCONTACT_FORM','tblcontact_form');
define('TBLWIDGET','tblwidget');


define('TBLADMIN_NOTE','tbladmin_node');

define('TBLGALLERIES','tblgalleries');

define('TBL_COUNT_ONLINE','tbl_count_online');

define('TBLNEWSLETTER','tblnewsletter');

define('TBL_PRODUCT_VIEWED','tbl_product_viewed');
define('TBLCODECONFIG','tblcodeconfig');


define('TBLPROVINCE','province');
define('TBLDISTRICT','district');
define('TBLWARD','ward');
define('TBLSTREET','street');

define('TBLCOMMENT','forum_comments');
define('TBLREPLY','forum_replies');
define('TBLVIEW_TOPIC','forum_views');


define('TBLCHART','tblchart');
define('TBLCHART_CATE','tblchart_cate');
define('TBLCHART_VALUE','tblchart_value');

define('TBLCOOPERATION','tblcooperation');
define('TBLCOOPERATION_TYPE','tblcooperation_type');

define('TBLCOORDINATES','tblcoordinates');

define('TBLOCCUPATION','tbloccupation');
define('TBLBRANCH_CAREER','tblbranch_career');
define('TBLCANDIDATE','tblcandidate');
define('TBLCAREER','tblcareer');
?>