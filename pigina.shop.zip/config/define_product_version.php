<?php
	/* define array thumb size */
	$_ARR_SIZE_THUMB_PRODUCT_VERSION = array(
	    0 => array(480,480),
	);
	define("_ARR_SIZE_THUMB_PRODUCT_VERSION",serialize($_ARR_SIZE_THUMB_PRODUCT_VERSION));

?>