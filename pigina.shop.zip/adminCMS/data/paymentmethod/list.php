<?php  

    /* set - tieu de trang web */
    $page_title = $LANG['list-paymentmethod_breadcrumb'];
?>