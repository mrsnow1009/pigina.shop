<?php  

    /* set - tieu de trang web */
    $page_title = $LANG['list-template'];
?>