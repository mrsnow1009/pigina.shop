<?php  
    // file_exists(_PHISICAL_PATH_ADMIN_CONTROLLER_BANNER)?include_once(_PHISICAL_PATH_ADMIN_CONTROLLER_BANNER):die(_PHISICAL_PATH_ADMIN_CONTROLLER_BANNER.' khong ton tai');

	/* get session dang nhap */
    // $webmt_level = $Session->get("webmt_level");

    /* set - tieu de trang web */
    $page_title = $LANG['list-banner'];

?>