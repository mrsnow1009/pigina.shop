 const LANG = {
	 '_DO_YOU_WANT_TO_DELETE_THIS_FILE' : 'Bạn muốn xóa file này?',
	 '_NOTE_DELETE_OBJECT' : 'Đối tượng này sẽ bị xóa. Bạn có chắc không?',
	 '_NOTE_CHOOSE_OBJECT_TO_DELETE' : 'Vui lòng chọn ít nhất một đối tượng để xoá!',
	 '_DELETE_SUCCESSFULLY' : 'Xóa đối tượng thành công!',
	 '_ERROR_TRY_AGAIN' : 'Có lỗi xảy ra. Vui lòng thử lại!',
 };  
