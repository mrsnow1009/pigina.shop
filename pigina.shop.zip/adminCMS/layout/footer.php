<nav class="navbar navbar-expand-sm bg-dark navbar-dark fixed-bottom">
    <div class="container-fluid">
        <a class="navbar-brand" href="javascript:void(0)" title="">2007 © Redsun Admin</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbar-bottom">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbar-bottom">
            <ul class="navbar-nav w-100">
                <li class="nav-item">
                    <a class="nav-link" href="javascript:void(0)" title="">Hệ quản trị website v9.0</a>
                </li>
                <li class="nav-item dropup ms-sm-auto">
                    <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" title="">Dropdown</a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="#" title="">Link</a></li>
                        <li><a class="dropdown-item" href="#" title="">Another link</a></li>
                        <li><a class="dropdown-item" href="#" title="">A third link</a></li>
                    </ul>
                </li> 
            </ul>
        </div>
    </div>
</nav>   