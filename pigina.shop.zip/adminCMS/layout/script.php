<script type="text/javascript" src="assets/js/jquery-3.7.1.min.js"></script>
<script type="text/javascript" src="assets/plugin/bootstrap-5.3.3/js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.easing.min.js"></script>
<script type="text/javascript" src="assets/js/jquery.validate.min.js"></script>
<!-- custom js -->
<script>
	var window_width = window.innerWidth;
	var path_admin = '<?php echo _ROOT_PATH_ADMIN;?>';
</script>
<script type="text/javascript" src="assets/js/lang/lang_vn.js"></script>
<script type="text/javascript" src="assets/js/custom.js"></script>