var _screen_width = window.innerWidth;

$(document).ready(function () {

});

/******************************
  MINI CART
******************************/
$(document).ready(function () {
	$('.show-cart-click').click(function (){
		$('#cart-drawer').toggleClass('show');
	});
});










