 const LANG = {
	 '_DO_YOU_WANT_TO_DELETE_THIS_FILE' : 'Bạn muốn xóa file này?',
	 '_THIS_OBJECT_WILL_BE_DELETED_ARE_YOU_SURE' : 'Đối tượng này sẽ bị xóa. Bạn có chắc không?',
 };  
 