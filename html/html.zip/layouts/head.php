
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta charset="UTF-8">
<meta name="HandheldFriendly" content="True">
<meta name="MobileOptimized" content="320">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="theme-color" content="#9b5e5e">

<!-- favicon -->
<link type="image/x-icon" rel="icon" href="images/logo/favicon.png">
<link type="image/x-icon" rel="shortcut icon" href="images/logo/favicon.png">
<link type="image/x-icon" rel="apple-touch-icon" href="images/logo/favicon.png">
<!--[if IE]>
    <link rel="shortcut icon" href="assets/images/favicon.png">
<![endif]-->

<!-- bootstrap -->
<link media="all" rel="stylesheet" type="text/css" href="../assets/plugin/bootstrap-5.3.3/css/bootstrap.min.css" />

<!-- font-awesome -->
<link media="all" rel="stylesheet" type="text/css" href="../assets/css/font-awesome.6.6.0/css/all.css" />
<link media="all" rel="stylesheet" type="text/css" href="../assets/css/font-awesome.6.6.0/css/sharp-duotone-solid.css">
<link media="all" rel="stylesheet" type="text/css" href="../assets/css/font-awesome.6.6.0/css/sharp-thin.css">
<link media="all" rel="stylesheet" type="text/css" href="../assets/css/font-awesome.6.6.0/css/sharp-solid.css">
<link media="all" rel="stylesheet" type="text/css" href="../assets/css/font-awesome.6.6.0/css/sharp-regular.css">
<link media="all" rel="stylesheet" type="text/css" href="../assets/css/font-awesome.6.6.0/css/sharp-light.css">

<!-- custom css -->
<link media="all" rel="stylesheet" type="text/css" href="../assets/plugin/swiper-11.0.6/css/swiper-bundle.min.css" />
<link media="all" rel="stylesheet" type="text/css" href="../view/template/assets/css/custom.css?t=<?php echo time(); ?>" />